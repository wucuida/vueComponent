<template>
	<div>
		<li :class="className" @mouseLeave="handleMouseLeave" @mouseEnter="handleMouseEnter">
			<div>{{title}}</div>
			<sub-popup-menu>{{children}}</sub-popup-menu>
		</li>
	</div>
</template>