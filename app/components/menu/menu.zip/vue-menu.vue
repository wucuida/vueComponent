<template>
	<div>
		<ul>
			<li v-for="child in children">{{child.value}}</li>
		</ul>
	</div>
</template>
<script type="text/javascript">
import {noop} from '../../util/util' 
import menumixin from '../../util/menu-mixin'
export default {
	data () {
		return {
		}
	},
	props: {
		openSubMenuOnMouseEnter: {
			type: Boolean,
			default: true
		},
		closeSubMenuOnMouseLeave: {
			type: Boolean,
			default: true
		},
		onClick: {
			type: Function,
			default: noop
		},
		onSelect: {
			type: Function,
			default: noop
		},
		onOpen: {
			type: Function,
			default: noop
		},
		onClose: {
			type: Function,
			default: noop
		},
		onDeselect: {
			type: Function,
			default: noop
		},
		children: {
			type: Array,
			default () {
				return [{key:1, value: 'a'}, 
						{key:2, value: 'b'}, 
						{key:3, value: 'c'}]
			}
		}

	},
	mixins: [menumixin],
	created () {

	}
 }

</script>
