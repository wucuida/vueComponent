<template>
<div :class="ulClass">
	<a :class="liClass" @click="handleToggle">{{model.name}}<span class="caret" v-if="isFolder"></span></a>
	<a v-show="open" v-if="isFolder" :class="liClass">
		<vue-ul v-for="c in model.children" :model='c' 
			:mode="mode" :on-item-click="onItemClick">
		</vue-ul>
	</a>
</div>
</template>

<script type="text/javascript">
import Vue from 'vue'
export default Vue.extend({
	name: 'vue-ul',
	data () {
		return {
			open: false,
			transitionName: 'fade',
			outerClass: '',//'btn-group',
			innerClass: 'dropdown-toggle',
			ulClass: 'list-group',
			liClass: 'list-group-item myflot',
			// caret: 'caret'
		}
	},
	props: {
		model: Object,
		mode: {
			type: String,
			default: 'vertical'
		},
		onItemClick: Function,
	},
	computed:{
		isFolder () {
			return this.model.children && this.model.children.length
		}
	},
	methods: {
		// handleMouseOver () {
		// 	this.open = true
		// },
		// handleMouseOut () {
		// 	this.open = false
		// },
		test() {
			console.log('this is a test Function')
		},
		handleToggle () {
			this.open = !this.open;
			if(! this.isFolder){
				this.doClick()
			}else{
				
			}
		},
		doClick () {
			console.log('执行组件固定代码');
			if(this.onItemClick){
				this.onItemClick()
			}else{
				console.log('父组件没有为子组件传递click函数')
			}
		}
	},
	created() {
	}
})
</script>
<style>
.myfloat {
	
}
</style>