import {isArrayOfString} from '../../util'
export default menuMinxin {
	props: {
		focusable: Boolean,
		multiple: Boolean,
		defaultActiveFirst: Boolean,
		visible: Boolean,
		activeKey: Boolean,
		selectedKeys:{
			validator: isArrayOfString,
		},
		defaultSelectedKeys:{
			validator: isArrayOfString,
		},
		defaultOpenKeys:{
			validator: isArrayOfString,
		},
		openKeys:{
			validator: isArrayOfString,
		},
		children: null
	},
	data () {
		return {
			prefixCls: 'rc-menu',
	        className: '',
	        mode: 'vertical',
	        level: 1,
	        inlineIndent: 24,
	        visible: true,
	        focusable: true,
		}
	}
}